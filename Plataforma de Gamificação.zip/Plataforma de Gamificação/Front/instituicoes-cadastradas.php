<?php
include "painelAdministrador.php";
?>

<!DOCTYPE html>

<html lang="en">
	<head>

    <meta charset="utf-8"> 
	
    <meta name="viewport" content="width=device-width, initial-scale=1"> 	
	
    <meta name="author" content="sumit kumar"> 
	
    <title>admin-template</title> 
	
    <link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	
    <link href="assets/bootstrap/css/font-awesome.css" rel="stylesheet" type="text/css">	
	
    <link href="assets/bootstrap/css/style.css" rel="stylesheet" type="text/css">

	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- CSS do Projeto -->
    <link href="assets/css/instituicoes-cadastradas.css" rel="stylesheet" type="text/css">



    
 <div class="container-fluid">
	<div class="row">

		<section class="content">
			<h1>Instituções Cadastradas</h1>
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="pull-right">
						</div>
						<div class="table-container">
							<table class="table my-table-filter">
								<tbody>
									<tr>
										<td>
											<div class="ckbox">
												<input type="checkbox" id="checkbox1">
												<label for="checkbox1"></label>
											</div>
										</td>
										<td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
										</td>
										<td>
											<div class="media">
												<a href="#" class="pull-left">
													<img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
												</a>
												<div class="media-body">
													<span class="media-meta pull-right">Febrero 13, 2016</span>
													<h4 class="title">
														Lorem Impsum
													</h4>
													<p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div class="ckbox">
												<input type="checkbox" id="checkbox3">
												<label for="checkbox3"></label>
											</div>
										</td>
										<td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
										</td>
										<td>
											<div class="media">
												<a href="#" class="pull-left">
													<img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
												</a>
												<div class="media-body">
													<span class="media-meta pull-right">Febrero 13, 2016</span>
													<h4 class="title">
														Lorem Impsum
													</h4>
													<p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div class="ckbox">
												<input type="checkbox" id="checkbox2">
												<label for="checkbox2"></label>
											</div>
										</td>
										<td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
										</td>
										<td>
											<div class="media">
												<a href="#" class="pull-left">
													<img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
												</a>
												<div class="media-body">
													<span class="media-meta pull-right">Febrero 13, 2016</span>
													<h4 class="title">
														Lorem Impsum
														</h4>
													<p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
												</div>
											</div>
										</td>
									</tr>
									<tr class="selected">
										<td>
											<div class="ckbox">
												<input type="checkbox" id="checkbox4" checked>
												<label for="checkbox4"></label>
											</div>
										</td>
										<td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
										</td>
										<td>
											<div class="media">
												<a href="#" class="pull-left">
													<img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
												</a>
												<div class="media-body">
													<span class="media-meta pull-right">Febrero 13, 2016</span>
													<h4 class="title">
														Lorem Impsum
													</h4>
													<p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div class="ckbox">
												<input type="checkbox" id="checkbox5">
												<label for="checkbox5"></label>
											</div>
										</td>
										<td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
										</td>
										<td>
											<div class="media">
												<a href="#" class="pull-left">
													<img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
												</a>
												<div class="media-body">
													<span class="media-meta pull-right">Febrero 13, 2016</span>
													<h4 class="title">
														Lorem Impsum
													</h4>
													<p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
												</div>
											</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="content-footer">
					<p>
						Gamificação © - 2017 <br>
						Powered By Fábio De Moura, Guilherme Cipriano & Marlon Guarnieri
					</p>
				</div>
			</div>
		</section>
		
	</div>
</div>
    
    
    
    
    
    
    
    <script src="js/jquery-3.1.1.js"></script>    
    <script src="js/bootstrap.js"></script>
