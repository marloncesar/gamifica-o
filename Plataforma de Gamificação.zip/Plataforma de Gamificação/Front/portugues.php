

<!DOCTYPE html>
<html>
<head>
 	<title>Português</title>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

	<!-- Bootstrap -->

    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Local -->
	
	<link href="assets/css/progresso.css" rel="stylesheet" type="text/css">


</head>
 <body>

											<h1 style="text-align: center">Português</h1>
 <!--Assunto 1-->
        <div class="col-md-12 principal">
            <div class="profile-content">
    <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
			<div class="offer offer-success">
				<div class="shape">
					<div class="shape-text">
						<span class="glyphicon glyphicon glyphicon-th"></span>							
					</div>
				</div>
				<div class="offer-content">
					<h3 class="lead">
						 A definir
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
					</p>
					<h5>
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
			</div>
		</div>
	</div>
	<!--Assunto 1-->
    <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
			<div class="offer offer-success">
				<div class="shape">
					<div class="shape-text">
						<span class="glyphicon glyphicon glyphicon-th"></span>							
					</div>
				</div>
				<div class="offer-content">
					<h3 class="lead">
						 Lições Completas: <label class="label label-success">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
					</p>
					<h5>
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
			</div>
		</div>
	</div>
	<!--Assunto 1-->
    <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
			<div class="offer offer-success">
				<div class="shape">
					<div class="shape-text">
						<span class="glyphicon glyphicon glyphicon-th"></span>							
					</div>
				</div>
				<div class="offer-content">
					<h3 class="lead">
						 Lições Completas: <label class="label label-success">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
					</p>
					<h5>
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
			</div>
		</div>
	</div>
	<!--Assunto 1-->
    <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
			<div class="offer offer-success">
				<div class="shape">
					<div class="shape-text">
						<span class="glyphicon glyphicon glyphicon-th"></span>							
					</div>
				</div>
				<div class="offer-content">
					<h3 class="lead">
						 Lições Completas: <label class="label label-success">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
					</p>
					<h5>
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
			</div>
		</div>
	</div><!--Assunto 1-->
    <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
			<div class="offer offer-success">
				<div class="shape">
					<div class="shape-text">
						<span class="glyphicon glyphicon glyphicon-th"></span>							
					</div>
				</div>
				<div class="offer-content">
					<h3 class="lead">
						 Lições Completas: <label class="label label-success">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
					</p>
					<h5>
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
			</div>
		</div>
	</div><!--Assunto 1-->
    <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3">
			<div class="offer offer-success">
				<div class="shape">
					<div class="shape-text">
						<span class="glyphicon glyphicon glyphicon-th"></span>							
					</div>
				</div>
				<div class="offer-content">
					<h3 class="lead">
						 Lições Completas: <label class="label label-success">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
					</p>
					<h5>
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
	</body>
 </html>




PRIMEIRO TERMINAR O NÍVEL FÁCIL
Liberar pergutnas difíceis de acordo com o número de acertos
variar os níveis de acordo com as questóes