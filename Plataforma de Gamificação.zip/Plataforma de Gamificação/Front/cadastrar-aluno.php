<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Aluno</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <link rel='stylesheet prefetch' href='assets/font-awesome/css/font-awesome.min.css'>

  <link rel="stylesheet" href="assets/css/cadastrar-aluno.css">

  
</head>

<body>
  
<div class="container">
  <form>
    <div class="row">
      <h4>Conta</h4>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="Nome Completo"/>
        <div class="input-icon"><i class="fa fa-user"></i></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="password" placeholder="Senha"/>
        <div class="input-icon"><i class="fa fa-key"></i></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="password" placeholder="Confirmar Senha"/>
        <div class="input-icon"><i class="fa fa-key"></i></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="number" placeholder="Número De Matrícula"/>
        <div class="input-icon"><i class="fa fa-user"></i></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="Nome de Usuário"/>
        <div class="input-icon"><i class="fa fa-user"></i></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="Instituição De Ensino"/>
        <div class="input-icon"><i class="fa fa-user"></i></div>
      </div>
       <div class="input-group-select input-group-icon">
        <input type="select" placeholder="Ano"/>
        <div class="input-icon"><i class="fa fa-user"></i></div>
            <select>
            <option>6°ano</option>
            <option>7°ano</option>
            <option>8°ano</option>
            <option>9°ano</option>
            </select>
      </div>


















    </div>
    <div class="row">
      <div class="col-half">
        <h4>Data de Nascimento</h4>
        <div class="input-group">
          <div class="col-third">
            <input type="text" placeholder="DD"/>
          </div>
          <div class="col-third">
            <input type="text" placeholder="MM"/>
          </div>
          <div class="col-third">
            <input type="text" placeholder="YYYY"/>
          </div>
        </div>
      </div>
      <div class="col-half">
        <h4>Gênero</h4>
        <div class="input-group">
          <input type="radio" name="gender" value="male" id="gender-male"/>
          <label for="gender-male">Masculino</label>
          <input type="radio" name="gender" value="female" id="gender-female"/>
          <label for="gender-female">Feminino</label>
        </div>
      </div>
    </div>
    </div>
  </form>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script  src="assets/js/register-student.js"></script>

</body>
</html>
