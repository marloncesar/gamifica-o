<?php
include "painelAdministrador.php";
?>

<!DOCTYPE html>

<html lang="en">
    <head>
    
    <meta charset="utf-8"> 
	
    <meta name="viewport" content="width=device-width, initial-scale=1"> 	
	
    <meta name="author" content="sumit kumar"> 
	
    <title>Painel do Administrador</title> 
	
    <link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css">	
	
    <link href="assets/bootstrap/css/style.css" rel="stylesheet" type="text/css">

	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- CSS do Projeto -->
    <link href="assets/css/questoes.css" rel="stylesheet" type="text/css">



</head>
    <body>



<div class="container-fluid">
    <div class="row">

        <section class="content">
            <h1>Questões</h1>
                <div class="panel panel-default">
                    <div class="panel-body">                    
                    <div class="table-container">
                            <table class="table my-table-filter">
                                <tbody>
    <tr data-status="pendente" id="" class = "efeito">
                                        <td>
                                            
                                            <div class="ckbox">
                                                <input type="checkbox" id="checkbox3">
                                                <label for="checkbox3"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                            <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div class="media">
                                                <div class="media-body">
                                                    <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                    <h4 class="title">
                                                        Não pode?
                                                        
                                                    </h4>
                                                    <p class="summary">
                                                        <div class = "menu-content2" id = "esconder">
                                                        <br>
                                                        A.B
                                                        </br>
                                                        <br>
                                                        B.D
                                                        </br>
                                                        <br>
                                                        C.A
                                                        </br>
                                                        <br>
                                                        D.C <i class = "glyphicon glyphicon-ok"></i>
                                                        </br></p>
                                                        </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr data-status="pendente" id="" class = "efeito">
                                        <td>
                                            
                                            <div class="ckbox">
                                                <input type="checkbox" id="checkbox3">
                                                <label for="checkbox3"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="javascript:;" class="star">
                                                <i class="glyphicon glyphicon-trash"></i>
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div class="media">
                                                <div class="media-body">
                                                    <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                    <h4 class="title">
                                                        Não pode?
                                                        
                                                    </h4>
                                                    <p class="summary">
                                                        <div class = "menu-content2" id = "esconder">
                                                        <br>
                                                        A.B
                                                        </br>
                                                        <br>
                                                        B.D
                                                        </br>
                                                        <br>
                                                        C.A
                                                        </br>
                                                        <br>
                                                        D.C <i class = "glyphicon glyphicon-ok"></i>
                                                        </br></p>
                                                        </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr data-status="cancelado">
                                        <td>
                                            <div class="ckbox">
                                                <input type="checkbox" id="checkbox2">
                                                <label for="checkbox2"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div class="media">
                                                <div class="media-body">
                                                    <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                    <h4 class="title">
                                                        Teste
                                                    </h4>
                                                    <p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr data-status="aceito" class="selected">
                                        <td>
                                            <div class="ckbox">
                                                <input type="checkbox" id="checkbox4" checked>
                                                <label for="checkbox4"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div class="media">
                                                <div class="media-body">
                                                    <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                    <h4 class="title">
                                                        Lorem Impsum
                                                    </h4>
                                                    <p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr data-status="pendente">
                                        <td>
                                            <div class="ckbox">
                                                <input type="checkbox" id="checkbox5">
                                                <label for="checkbox5"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>
                                            <a href="" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                        <td>
                                            <div class="media">

                                                <div class="media-body">
                                                    <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                    <h4 class="title">
                                                        Titio Avô
                                                    </h4>
                                                    <p class="summary">Ut enim ad minim veniam, quis nostrud exercitation...</p>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>


                <div class="content-footer">
                    <p>
                        Gamificação © - 2017 <br>
                        Powered By Guilherme Cipriano, Marlon Guarniei & Fábio de Moura
                        </p>
                </div>
            </div>
        </section>

       <script src="js/jquery-3.1.1.js"></script>    
    <script src="js/bootstrap.js"></script>
    </body>

    

