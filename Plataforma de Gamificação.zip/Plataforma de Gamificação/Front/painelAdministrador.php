<!DOCTYPE html>

<html lang="en">
    <head>
    
    <meta charset="utf-8"> 
	
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="author" content="sumit kumar">
	
    <title>admin-template</title> 
	
    <link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	
    <link href="assets/bootstrap/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
    <link href="assets/bootstrap/css/style.css" rel="stylesheet" type="text/css">

	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- CSS do Projeto -->
    <link href="assets/css/painelAdministrador.css" rel="stylesheet" type="text/css">


    <body>
        <div class="container-2">
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-title">
                            <h2>Painel de Controle</h2>
       </div>
      </div>
     </div>


         <div class="row" >
                    <!--Respostas-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading green">
                             <i class="fa fa-check fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content green">
                         <div class="circle-tile-description text-faded">
                             Respostas
                         </div>
                         <div class="circle-tile-number text-faded">
                             1024
                         </div>
                         <a href="respostas.php" class="circle-tile-footer">Mais informações <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
                    <!--Rendimento Dos Estudantes-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading orange">
                             <i class="fa fa-line-chart fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content orange">
                         <div class="circle-tile-description text-faded">
                             Rendimento dos estudantes
                         </div>
                         <div class="circle-tile-number text-faded">
                             33 Atualizações
                         </div>
                         <a href="#" class="circle-tile-footer">Ver Mais <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
                    <!--Questões-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading blue">
                             <i class="fa fa-question fa-fw fa-4x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content blue">
                         <div class="circle-tile-description text-faded">
                             Questões Cadastradas
                         </div>
                         <div class="circle-tile-number text-faded">
                             256
                             <span id="sparklineB"></span>
                         </div>
                         <a href="questoes.php" class="circle-tile-footer">Visualizar por matérias <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>

                <!--Perguntas a Analisar -->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading purple">
                             <i class="fa fa-comments fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content purple">
                         <div class="circle-tile-description text-faded">
                             Perguntas a Analisar
                         </div>
                         <div class="circle-tile-number text-faded">
                             96
                             <span id="sparklineD"></span>
                         </div>
                         <a href="analizar-perguntas.php" class="circle-tile-footer">Analisar perguntas <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>

       <script src="js/jquery-3.1.1.js"></script>    
    <script src="js/bootstrap.js"></script>
    </body>

    

