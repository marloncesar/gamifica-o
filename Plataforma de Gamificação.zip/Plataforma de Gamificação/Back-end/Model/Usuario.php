<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 27/03/18
 * Time: 09:06
 */

include 'Conexao.php';

class Usuario
{
    private $login;
    private $senha;
    private $email;
    private $id_user;
    private $data_nascimento;

    public function __construct($login, $senha, $email, $id_user, $data_nascimento)
    {

        $this->login = $login;
        $this->senha = $senha;
        $this->email = $email;
        $this->id_user = $id_user;
        $this->data_nascimento = $data_nascimento;

    }

    public function cadastrar_usuario(): Usuario{

        $sql = new Conexao();
        $sql::getConexao();

        $insert = "INSERT INTO usuario(login, senha, email, id_user, data_nascimento) VALUES ('$this->login', '$this->senha', '$this->email', '$this->id_user', '$this->data_nascimento')";
    }
    public function editar_usuario(): Usuario{
        return $Usuario;
    }
    public function excluir_usuario(): Usuario{
        return $Usuario;
    }

    public function getLogin(){
        return $this->login;
    }

    public function setLogin($login){
        $this->login = $login;
    }

    public function getSenha(){
        return $this->senha;
    }

    public function setSenha($senha){
        $this->senha = $senha;
    }

    public function getEmail(){
        return $this->email;
    }

    public function setEmail($email){
        $this->email = $email;
    }

    public function getIdUser(){
        return $this->id_user;
    }

    public function setIdUser($id_user){
        $this->id_user = $id_user;
    }

    public function getDataNascimento(){
        return $this->data_nascimento;
    }

    public function setDataNascimento($data_nascimento){
        $this->data_nascimento = $data_nascimento;
    }



}